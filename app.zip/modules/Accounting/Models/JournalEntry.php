<?php

namespace Modules\Accounting\Models;

use App\Models\User;
use DomainException;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Modules\Core\Models\Branch;
use Modules\Core\Models\Company;
use Modules\Core\Models\Currency;
use Modules\Core\Models\FinancialPeriod;

class JournalEntry extends Model
{
    use SoftDeletes;

    public const StatusDraft = 'draft';

    public const StatusPosted = 'posted';

    public const StatusCancelled = 'cancelled';

    public const StatusReversed = 'reversed';

    protected $fillable = [
        'doc_number',
        'doc_num',
        'entry_date',
        'company_id',
        'financial_period_id',
        'branch_id',
        'currency_id',
        'exchange_rate',
        'description',
        'notes',
        'source_type',
        'source_id',
        'source_doc_num',
        'reference_no',
        'status',
        'is_system_generated',
        'is_posted',
        'posted_at',
        'posted_by',
        'approved',
        'approved_at',
        'approved_by',
        'reversed_entry_id',
        'created_by',
        'updated_by',
        'deleted_by',
        'restored_by',
        'restored_at',
    ];

    protected $attributes = [
        'exchange_rate' => 1,
        'status' => self::StatusDraft,
        'is_system_generated' => false,
        'is_posted' => false,
        'approved' => false,
    ];

    protected function casts(): array
    {
        return [
            'entry_date' => 'date',
            'exchange_rate' => 'decimal:6',
            'is_system_generated' => 'boolean',
            'is_posted' => 'boolean',
            'posted_at' => 'datetime',
            'approved' => 'boolean',
            'approved_at' => 'datetime',
            'created_at' => 'datetime',
            'updated_at' => 'datetime',
            'deleted_at' => 'datetime',
            'restored_at' => 'datetime',
        ];
    }

    public function getRouteKeyName(): string
    {
        return 'doc_num';
    }

    public function localizedSystemDescription(?string $description = null): string
    {
        $description ??= (string) $this->description;
        if (! $this->is_system_generated) {
            return $description;
        }
        foreach (['opening_stock_cost_correction.title', 'inventory.movements.receipt_completion_title',
            'inventory_standard_cost.settlements', 'inventory_periodic_cost.title'] as $key) {
            foreach (['ar', 'en'] as $locale) {
                $sourceLabel = (string) __($key, [], $locale);
                if ($description === $sourceLabel || str_starts_with($description, $sourceLabel.' ')) {
                    return __($key).substr($description, strlen($sourceLabel));
                }
            }
        }

        return $description;
    }

    public function assertManuallyEditable(): void
    {
        if ($this->is_system_generated || $this->source_type !== null || $this->source_id !== null) {
            throw new DomainException(__('opening_balances.messages.system_journal_entry_locked'));
        }

        if ($this->status !== self::StatusDraft || $this->is_posted) {
            throw new DomainException(__('journal_entries.messages.posted_locked'));
        }
    }

    public function lines(): HasMany
    {
        return $this->hasMany(JournalEntryLine::class)->orderBy('line_no');
    }

    public function financialPeriod(): BelongsTo
    {
        return $this->belongsTo(FinancialPeriod::class);
    }

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function branch(): BelongsTo
    {
        return $this->belongsTo(Branch::class);
    }

    public function currency(): BelongsTo
    {
        return $this->belongsTo(Currency::class);
    }

    public function postedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'posted_by');
    }

    public function approvedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'approved_by');
    }

    public function createdBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function updatedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'updated_by');
    }

    public function deletedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'deleted_by');
    }

    public function restoredBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'restored_by');
    }

    public function reversedEntry(): BelongsTo
    {
        return $this->belongsTo(self::class, 'reversed_entry_id');
    }
}
