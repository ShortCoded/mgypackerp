<?php

namespace Modules\Accounting\Exports;

use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithCustomValueBinder;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithStrictNullComparison;
use Modules\Accounting\Services\JournalSourceLabelService;
use PhpOffice\PhpSpreadsheet\Cell\Cell;
use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\Cell\DefaultValueBinder;

class LedgerReportExport extends DefaultValueBinder implements FromArray, ShouldAutoSize, WithCustomValueBinder, WithHeadings, WithStrictNullComparison
{
    /**
     * @param  array<string, mixed>  $result
     */
    public function __construct(
        private readonly array $result,
        private readonly string $type = 'account_ledger',
    ) {}

    public function bindValue(Cell $cell, mixed $value): bool
    {
        $amountColumns = match ($this->type) {
            'general_journal' => ['I', 'J'],
            'customer_statement' => ['G', 'H'],
            'supplier_statement' => ['E', 'F'],
            default => ['H', 'I', 'J', 'K'],
        };

        if ($cell->getRow() > 1
            && in_array($cell->getColumn(), $amountColumns, true)
            && is_string($value)
            && preg_match('/^-?\d+(?:\.\d+)?$/', $value) === 1) {
            $cell->setValueExplicit($value, DataType::TYPE_STRING);

            return true;
        }

        return parent::bindValue($cell, $value);
    }

    /**
     * @return list<list<string>>
     */
    public function array(): array
    {
        if ($this->type === 'general_journal') {
            return $this->generalJournalRows();
        }

        if ($this->isPartnerStatement()) {
            return $this->partnerStatementRows();
        }

        $rows = [[
            (string) data_get($this->result, 'filters.from_date'),
            __('ledger_reports.summary.opening'),
            '',
            '',
            '',
            '',
            '',
            (string) data_get($this->result, 'opening.debit'),
            (string) data_get($this->result, 'opening.credit'),
            (string) data_get($this->result, 'opening.debit'),
            (string) data_get($this->result, 'opening.credit'),
        ]];

        foreach ($this->result['movements'] as $movement) {
            $rows[] = [
                $movement['entry_date'],
                $this->sourceLabel($movement['source_type']),
                $movement['doc_num'],
                $movement['reference_no'] ?: $movement['source_doc_num'],
                $movement['description'],
                $movement['cost_center'],
                $movement['branch'],
                $movement['debit'],
                $movement['credit'],
                $movement['running_debit'],
                $movement['running_credit'],
            ];
        }

        $rows[] = [
            (string) data_get($this->result, 'filters.to_date'),
            __('ledger_reports.summary.period'),
            '',
            '',
            '',
            '',
            '',
            (string) data_get($this->result, 'period.debit'),
            (string) data_get($this->result, 'period.credit'),
            (string) data_get($this->result, 'ending.debit'),
            (string) data_get($this->result, 'ending.credit'),
        ];

        return $rows;
    }

    /**
     * @return list<string>
     */
    public function headings(): array
    {
        if ($this->type === 'general_journal') {
            return collect(['date', 'document', 'source_type', 'reference', 'account', 'description', 'cost_center', 'branch', 'debit', 'credit'])
                ->map(fn (string $column): string => __('ledger_reports.columns.'.$column))
                ->all();
        }

        if ($this->isPartnerStatement()) {
            return [
                __('ledger_reports.columns.date'),
                __('ledger_reports.columns.document'),
                __('ledger_reports.columns.reference'),
                __('ledger_reports.columns.description'),
                ...($this->type === 'customer_statement' ? [
                    __('ledger_reports.columns.collector'),
                    __('ledger_reports.columns.collection_source'),
                ] : []),
                __('ledger_reports.columns.debit'),
                __('ledger_reports.columns.credit'),
                __('ledger_reports.columns.balance'),
            ];
        }

        return [
            __('ledger_reports.columns.date'),
            __('ledger_reports.columns.source_type'),
            __('ledger_reports.columns.document'),
            __('ledger_reports.columns.reference'),
            __('ledger_reports.columns.description'),
            __('ledger_reports.columns.cost_center'),
            __('ledger_reports.columns.branch'),
            __('ledger_reports.columns.debit'),
            __('ledger_reports.columns.credit'),
            __('ledger_reports.columns.running_debit'),
            __('ledger_reports.columns.running_credit'),
        ];
    }

    /**
     * @return list<list<string>>
     */
    private function partnerStatementRows(): array
    {
        $rows = [];

        if ($this->result['opening_movements'] !== []) {
            $rows[] = ['', __('ledger_reports.summary.prior_details'), '', '', ...$this->partnerCollectionCells(), '', '', ''];

            foreach ($this->result['opening_movements'] as $movement) {
                $rows[] = [
                    $movement['entry_date'],
                    $movement['source_doc_num'] ?: $movement['doc_num'],
                    $movement['reference_no'] ?: '',
                    $movement['description'],
                    ...$this->partnerCollectionCells($movement),
                    $movement['debit'],
                    $movement['credit'],
                    $this->balanceLabel($movement['running_debit'], $movement['running_credit']),
                ];
            }
        }

        $rows[] = [
            (string) data_get($this->result, 'filters.from_date'),
            __('ledger_reports.summary.prior'),
            '',
            '',
            ...$this->partnerCollectionCells(),
            (string) data_get($this->result, 'opening.debit'),
            (string) data_get($this->result, 'opening.credit'),
            $this->balanceLabel(
                (string) data_get($this->result, 'opening.debit', '0'),
                (string) data_get($this->result, 'opening.credit', '0'),
            ),
        ];

        foreach ($this->result['movements'] as $movement) {
            $rows[] = [
                $movement['entry_date'],
                $movement['source_doc_num'] ?: $movement['doc_num'],
                $movement['reference_no'] ?: '',
                $movement['description'],
                ...$this->partnerCollectionCells($movement),
                $movement['debit'],
                $movement['credit'],
                $this->balanceLabel($movement['running_debit'], $movement['running_credit']),
            ];
        }

        $rows[] = [
            (string) data_get($this->result, 'filters.to_date'),
            __('ledger_reports.summary.period'),
            '',
            '',
            ...$this->partnerCollectionCells(),
            (string) data_get($this->result, 'period.debit'),
            (string) data_get($this->result, 'period.credit'),
            $this->balanceLabel(
                (string) data_get($this->result, 'ending.debit', '0'),
                (string) data_get($this->result, 'ending.credit', '0'),
            ),
        ];

        return $rows;
    }

    /** @return list<list<string>> */
    private function generalJournalRows(): array
    {
        $rows = collect($this->result['movements'])->map(fn (array $movement): array => [
            $movement['entry_date'],
            $movement['doc_num'],
            $this->sourceLabel($movement['source_type']),
            $movement['reference_no'] ?: $movement['source_doc_num'],
            $movement['account'],
            $movement['description'],
            $movement['cost_center'],
            $movement['branch'],
            $movement['debit'],
            $movement['credit'],
        ])->all();
        $rows[] = [
            (string) data_get($this->result, 'filters.to_date'),
            __('ledger_reports.summary.period'),
            '', '', '', '', '', '',
            (string) data_get($this->result, 'totals.debit'),
            (string) data_get($this->result, 'totals.credit'),
        ];

        return $rows;
    }

    private function sourceLabel(mixed $sourceType): string
    {
        return app(JournalSourceLabelService::class)->label($sourceType);
    }

    private function isPartnerStatement(): bool
    {
        return in_array($this->type, ['customer_statement', 'supplier_statement'], true);
    }

    /** @param array<string, mixed> $movement @return list<string> */
    private function partnerCollectionCells(array $movement = []): array
    {
        return $this->type === 'customer_statement'
            ? [(string) ($movement['collector'] ?? ''), (string) ($movement['collection_source'] ?? '')]
            : [];
    }

    private function balanceLabel(string $debit, string $credit): string
    {
        if ((float) $credit !== 0.0) {
            return $credit.' '.__('ledger_reports.balance.credit');
        }

        return $debit.' '.__('ledger_reports.balance.debit');
    }
}
