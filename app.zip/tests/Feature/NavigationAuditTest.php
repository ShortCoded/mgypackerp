<?php

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Routing\Route as RoutingRoute;
use Illuminate\Support\Facades\Lang;
use Modules\Auth\Database\Seeders\PermissionSeeder;
use Modules\Auth\Models\Role;
use Modules\Core\Services\BreadcrumbService;
use Modules\Core\Services\ErpUi\ErpUiScreenRegistry;
use Modules\Core\Services\MenuConfigFileOrder;
use Modules\Core\Services\MenuService;
use Modules\Core\Services\NavigationSearchService;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\PermissionRegistrar;

/**
 * @param  list<array<string, mixed>>  $items
 * @param  list<string>  $labelPath
 * @param  list<string>  $textPath
 * @return list<array<string, mixed>>
 */
function navigationAuditRecords(array $items, array $labelPath = [], array $textPath = []): array
{
    $records = [];

    foreach ($items as $item) {
        $currentLabelPath = [...$labelPath, (string) $item['label']];
        $resolvedText = $item['text'] ?? $item['title'] ?? $item['label'];
        $currentTextPath = [...$textPath, is_string($resolvedText) ? $resolvedText : (string) $item['label']];
        $records[] = [
            ...$item,
            'label_path' => $currentLabelPath,
            'text_path' => $currentTextPath,
            'stable_path' => implode(' > ', $currentLabelPath),
        ];
        $records = [
            ...$records,
            ...navigationAuditRecords($item['children'] ?? [], $currentLabelPath, $currentTextPath),
        ];
    }

    return $records;
}

/**
 * @param  list<array<string, mixed>>  $items
 * @return list<array<string, mixed>>
 */
function navigationAuditRoutedItems(array $items): array
{
    return collect(navigationAuditRecords($items))
        ->filter(fn (array $item): bool => is_string($item['route'] ?? null) && $item['route'] !== '')
        ->values()
        ->all();
}

/**
 * @param  array<string, mixed>  $item
 */
function navigationAuditRouteFingerprint(array $item): string
{
    return $item['route'].'|'.json_encode($item['route_params'] ?? [], JSON_THROW_ON_ERROR);
}

function navigationAuditNormalizedUrl(string $url): string
{
    $path = parse_url($url, PHP_URL_PATH);
    $query = parse_url($url, PHP_URL_QUERY);
    $normalizedPath = is_string($path) && $path !== '' ? '/'.ltrim($path, '/') : '/';

    if ($normalizedPath !== '/') {
        $normalizedPath = rtrim($normalizedPath, '/');
    }

    if (! is_string($query) || $query === '') {
        return $normalizedPath;
    }

    parse_str($query, $parameters);
    ksort($parameters);

    return $normalizedPath.'?'.http_build_query($parameters);
}

function navigationAuditAdmin(): User
{
    app(PermissionSeeder::class)->run();

    $admin = User::factory()->create();
    $admin->assignRole(Role::query()->where('name', 'admin')->where('guard_name', 'web')->firstOrFail());

    return $admin;
}

function navigationAuditActor(string $permission): User
{
    app(PermissionRegistrar::class)->forgetCachedPermissions();
    Permission::findOrCreate($permission, 'web');

    $actor = User::factory()->create();
    $actor->givePermissionTo($permission);

    return $actor;
}

/**
 * @param  array<string, scalar>  $query
 */
function navigationAuditRequest(string $routeName, array $query = []): void
{
    $request = Request::create('/_navigation-audit', 'GET', $query);
    $request->setRouteResolver(fn (): RoutingRoute => new RoutingRoute(
        ['GET'],
        '/_navigation-audit',
        ['as' => $routeName],
    ));

    app()->instance('request', $request);
}

test('domain cleanup preserves the complete route and normalized URL inventory', function (string $phaseMode, bool $includeExpanded): void {
    config()->set('erp.phase_mode', $phaseMode);
    $sourceItems = [];

    foreach (app(MenuConfigFileOrder::class)->files() as $file) {
        $configuredItems = require $file;

        if (is_array($configuredItems)) {
            $sourceItems = [...$sourceItems, ...$configuredItems];
        }
    }

    if ($includeExpanded) {
        $sourceItems = [...$sourceItems, ...app(ErpUiScreenRegistry::class)->menuItems()];
    }

    $sourceRoutes = collect(navigationAuditRoutedItems($sourceItems));
    $sourceFingerprints = $sourceRoutes
        ->map(fn (array $item): string => navigationAuditRouteFingerprint($item))
        ->unique()
        ->sort()
        ->values();
    $sourceUrls = $sourceRoutes
        ->map(fn (array $item): string => navigationAuditNormalizedUrl(route($item['route'], $item['route_params'] ?? [])))
        ->unique()
        ->sort()
        ->values();
    $organizedRoutes = collect(navigationAuditRoutedItems(app(MenuService::class)->structure()));
    $organizedFingerprints = $organizedRoutes
        ->map(fn (array $item): string => navigationAuditRouteFingerprint($item))
        ->sort()
        ->values();
    $organizedUrls = $organizedRoutes
        ->map(fn (array $item): string => navigationAuditNormalizedUrl($item['url']))
        ->sort()
        ->values();

    expect($organizedRoutes)->toHaveCount($sourceFingerprints->count())
        ->and($organizedFingerprints)->toEqual($sourceFingerprints)
        ->and($organizedUrls)->toEqual($sourceUrls)
        ->and($organizedFingerprints->duplicates())->toBeEmpty()
        ->and($organizedUrls->duplicates())->toBeEmpty();
})->with([
    'legacy navigation' => ['legacy', false],
    'expanded navigation' => ['expanded', true],
]);

test('fully authorized rendered navigation is unique and identical across locales', function (): void {
    config()->set('erp.phase_mode', 'expanded');
    $admin = navigationAuditAdmin();
    $localeRoutes = [];

    foreach (['en', 'ar'] as $locale) {
        app()->setLocale($locale);
        $records = collect(navigationAuditRecords(app(MenuService::class)->getMenu($admin)));
        $routes = $records->filter(fn (array $item): bool => is_string($item['route'] ?? null));
        $routeFingerprints = $routes->map(fn (array $item): string => navigationAuditRouteFingerprint($item));
        $normalizedUrls = $routes->map(fn (array $item): string => navigationAuditNormalizedUrl($item['url']));

        expect($records->count())->toBeGreaterThan($routes->count())
            ->and($routes)->not->toBeEmpty()
            ->and($routeFingerprints->duplicates())->toBeEmpty()
            ->and($normalizedUrls->duplicates())->toBeEmpty();

        $localeRoutes[$locale] = $routeFingerprints->sort()->values()->all();
    }

    expect($localeRoutes['ar'])->toBe($localeRoutes['en']);
});

test('every visible label has paired menu translations or the approved bilingual registry resolver', function (): void {
    config()->set('erp.phase_mode', 'expanded');
    $admin = navigationAuditAdmin();
    $localizedRecords = [];

    foreach (['en', 'ar'] as $locale) {
        app()->setLocale($locale);
        $localizedRecords[$locale] = collect(navigationAuditRecords(app(MenuService::class)->getMenu($admin)))
            ->keyBy('stable_path');
    }

    app()->setLocale('en');
    $registryLabels = collect(navigationAuditRecords(app(ErpUiScreenRegistry::class)->menuItems()))
        ->pluck('label')
        ->unique();
    $approvedAcronyms = ['BOM', 'CAPA', 'PWA', 'QC'];

    expect($localizedRecords['ar']->keys()->all())->toBe($localizedRecords['en']->keys()->all());

    foreach ($localizedRecords['en'] as $stablePath => $english) {
        $arabic = $localizedRecords['ar'][$stablePath];
        $translationKey = 'menu.'.$english['label'];
        $hasEnglishKey = Lang::has($translationKey, 'en');
        $hasArabicKey = Lang::has($translationKey, 'ar');

        expect($hasArabicKey)->toBe($hasEnglishKey);
        expect($english['title'])->toBe($english['text'])
            ->and($arabic['title'])->toBe($arabic['text']);

        if (! $hasEnglishKey) {
            expect($registryLabels)->toContain($english['label'])
                ->and($english['text'] !== $arabic['text'] || in_array($english['text'], $approvedAcronyms, true))->toBeTrue();
        }

        expect(preg_match('/[\x{0600}-\x{06FF}]/u', $english['text']))->toBe(0);

        if (! in_array($arabic['text'], $approvedAcronyms, true)) {
            expect(preg_match('/[\x{0600}-\x{06FF}]/u', $arabic['text']))->toBe(1);
            expect(preg_match('/[A-Za-z]/', $arabic['text']))->toBe(0);
        }
    }

    $expectedTranslations = [
        'sales_orders' => ['Sales Orders', 'أوامر المبيعات'],
        'deliveries' => ['Issue Orders', 'أوامر الصرف'],
        'sales_invoices' => ['Sales Invoices', 'فواتير المبيعات'],
        'customer_collections' => ['Customer Collections', 'تحصيلات العملاء'],
        'sales_returns' => ['Sales Returns', 'مرتجعات المبيعات'],
        'procurement_cycle_report' => ['Procurement Cycle Report', 'تقرير دورة المشتريات'],
        'inventory_movements' => ['Inventory Movements', 'حركات المخزون'],
        'inventory_operational_reports' => ['Inventory Operational Reports', 'تقارير عمليات المخزون'],
        'inventory_stock_counts' => ['Physical Stock Counts', 'الجرد الفعلي للمخزون'],
        'production_quality' => ['Production Quality Management', 'إدارة جودة الإنتاج'],
        'production_work_orders' => ['Production Work Orders', 'أوامر الإنتاج'],
        'production_runs' => ['Production Runs', 'تشغيلات الإنتاج'],
        'production_operational_reports' => ['Production Operational Reports', 'تقارير عمليات الإنتاج'],
        'reports_sales_sales_orders' => ['Sales Orders', 'أوامر المبيعات'],
        'fixed_asset_depreciation' => ['Fixed Asset Depreciation', 'إهلاك الأصول الثابتة'],
        'fixed_asset_reports' => ['Fixed Asset Reports', 'تقارير الأصول الثابتة'],
    ];

    foreach ($expectedTranslations as $label => [$english, $arabic]) {
        expect(Lang::get("menu.{$label}", [], 'en'))->toBe($english)
            ->and(Lang::get("menu.{$label}", [], 'ar'))->toBe($arabic);
    }
});

test('production cycle screens and reports have one canonical owning domain', function (): void {
    config()->set('erp.phase_mode', 'expanded');
    app()->setLocale('en');
    $admin = navigationAuditAdmin();
    $menu = app(MenuService::class)->getMenu($admin);
    $records = collect(navigationAuditRecords($menu));
    $reportPaths = [
        'admin.inventory.reports.index' => ['inventory', 'inventory_module_reports', 'inventory_operational_reports'],
        'admin.production.reports.index' => ['production', 'production_management', 'production_reports_operations', 'production_reports_overview'],
        'admin.production.reports.quality' => ['production', 'quality', 'quality_reports', 'production_reports_quality'],
        'admin.production.reports.receipts' => ['inventory', 'inventory_module_reports', 'production_reports_receipts'],
    ];

    foreach ($reportPaths as $routeName => $expectedPath) {
        $matches = $records
            ->where('route', $routeName)
            ->filter(fn (array $record): bool => $record['label_path'] === $expectedPath)
            ->values();

        expect($matches)->toHaveCount(1)
            ->and($matches->first()['label_path'])->toBe($expectedPath);
    }

    foreach ([
        'admin.sales.sales-orders.index' => 'sales',
        'admin.sales.delivery-notes.index' => 'sales',
        'admin.sales.sales-invoices.index' => 'sales',
        'admin.sales.customer-receipts.index' => 'sales',
        'admin.sales.sales-returns.index' => 'sales',
        'admin.production.work-orders.index' => 'production',
        'admin.production.quality.index' => 'production',
    ] as $routeName => $expectedModule) {
        $matches = $records->where('route', $routeName)->values();

        expect($matches)->toHaveCount(1)
            ->and($matches->first()['label_path'][0])->toBe($expectedModule);
    }

    expect(collect($menu)->pluck('label'))->not->toContain('finance', 'quality', 'fixed_assets', 'maintenance')
        ->and(collect($menu)->pluck('label'))->toContain('inventory', 'production', 'accounting_costing');

    foreach ($records as $parent) {
        foreach ($parent['children'] ?? [] as $child) {
            expect($child['text'])->not->toBe($parent['text']);
        }
    }
});

test('report-only permissions retain access, hide empty module parents, and activate the complete canonical chain', function (string $permission, string $routeName, string $subgroup, string $label, array $expectedTopLabels, array $query = []): void {
    config()->set('erp.phase_mode', 'expanded');
    app()->setLocale('en');
    $actor = navigationAuditActor($permission);
    navigationAuditRequest($routeName, $query);

    $menu = app(MenuService::class)->getMenu($actor);
    $records = collect(navigationAuditRecords($menu));
    $topLabels = collect($menu)->pluck('label');
    $leaf = $records->first(fn (array $item): bool => $item['route'] === $routeName && $item['label'] === $label);
    $activePath = collect($records)
        ->filter(fn (array $item): bool => $leaf !== null && array_slice($leaf['label_path'], 0, count($item['label_path'])) === $item['label_path'])
        ->filter(fn (array $item): bool => $item['label'] !== 'dashboard');

    expect($topLabels->all())->toBe($expectedTopLabels)
        ->and($records->filter(fn (array $item): bool => $item['route'] === $routeName && $item['label'] === $label))->toHaveCount(1)
        ->and($leaf)->not->toBeNull()
        ->and($leaf['active'])->toBeTrue()
        ->and($activePath->every(fn (array $item): bool => $item['active'] === true))->toBeTrue()
        ->and($activePath->slice(0, -1)->every(fn (array $item): bool => $item['open'] === true))->toBeTrue()
        ->and($leaf['permission'])->toBe($permission);
})->with([
    'sales report' => ['reports.sales.sales_orders.view', 'admin.reports.sales.sales-orders.index', 'financial_analysis_reports', 'sales_report_financial', ['dashboard', 'sales', 'accounting_costing', 'human_resources'], ['report' => 'financial']],
    'purchase report' => ['reports.purchases.view', 'admin.purchases.procurement-cycle-report.index', 'purchase_reports', 'report_purchase_requests', ['dashboard', 'purchases', 'accounting_costing', 'human_resources'], ['report_type' => 'purchase_requests']],
    'inventory report' => ['inventory.reports.operational', 'admin.inventory.reports.index', 'inventory_module_reports', 'inventory_operational_reports', ['dashboard', 'inventory', 'human_resources']],
    'production report' => ['production.reports.operational', 'admin.production.reports.index', 'production_reports_operations', 'production_reports_overview', ['dashboard', 'inventory', 'production', 'human_resources']],
    'account ledger' => ['reports.account_ledger.view', 'admin.accounting.reports.account-ledger', 'accounting_costing_reports', 'account_ledger', ['dashboard', 'accounting_costing', 'human_resources']],
    'customer statement' => ['reports.customer_statement.view', 'admin.accounting.reports.customer-statement', 'sales_cycle_reports', 'customer_statement', ['dashboard', 'sales', 'human_resources']],
    'supplier statement' => ['reports.supplier_statement.view', 'admin.accounting.reports.supplier-statement', 'purchase_reports', 'supplier_statement', ['dashboard', 'purchases', 'human_resources']],
    'fixed asset report' => ['fixed_assets.reports', 'admin.fixed-assets.reports.index', 'asset_reports', 'fixed_asset_reports', ['dashboard', 'accounting_costing', 'human_resources']],
]);

test('financial analysis is a direct accounting group backed only by working report controllers', function (): void {
    config()->set('erp.phase_mode', 'expanded');
    app()->setLocale('en');
    $admin = navigationAuditAdmin();
    $records = collect(navigationAuditRecords(app(MenuService::class)->getMenu($admin)));
    $group = $records->firstWhere('stable_path', 'accounting_costing > financial_analysis_reports');

    expect($group)->not->toBeNull()
        ->and(collect($group['children'])->pluck('label')->all())->toContain(
            'sales_report_financial',
            'sales_report_period',
            'sales_report_customer',
            'sales_report_product',
            'sales_report_receivables',
            'sales_report_collections',
            'sales_report_returns',
            'report_purchases_by_supplier',
            'report_purchases_by_item',
            'report_purchases_by_period',
            'report_price_history',
            'report_supplier_outstanding',
            'report_due_supplier_installments',
            'report_supplier_aging',
            'report_upcoming_supplier_payments',
        );

    foreach ($group['children'] as $child) {
        $route = app('router')->getRoutes()->getByName($child['route']);

        expect($route)->not->toBeNull()
            ->and($route->getActionName())->not->toContain('ErpUiScreenController');
    }
});

test('navigation search returns only permitted unique destinations and uses canonical localized report paths', function (): void {
    config()->set('erp.phase_mode', 'expanded');
    $admin = navigationAuditAdmin();
    $search = app(NavigationSearchService::class);

    app()->setLocale('en');
    $results = collect($search->search($admin, 'admin', 1000)['results']);
    $menuUrls = collect(navigationAuditRoutedItems(app(MenuService::class)->getMenu($admin)))
        ->pluck('url')
        ->map(fn (string $url): string => navigationAuditNormalizedUrl($url));
    $resultUrls = $results->pluck('url')
        ->map(fn (string $url): string => navigationAuditNormalizedUrl($url));

    expect($results)->not->toBeEmpty()
        ->and($resultUrls->duplicates())->toBeEmpty()
        ->and($resultUrls->diff($menuUrls))->toBeEmpty();

    $salesReport = collect($search->search($admin, 'sales orders', 100)['results'])
        ->firstWhere('route_name', 'admin.reports.sales.sales-orders.index');

    expect($salesReport['parent_path'])->toBe('Sales / Sales Reports');

    app()->setLocale('ar');
    $inventoryReport = collect($search->search($admin, 'تقارير عمليات المخزون', 100)['results'])
        ->firstWhere('route_name', 'admin.inventory.reports.index');
    $productionQuality = collect($search->search($admin, 'إدارة جودة الإنتاج', 100)['results'])
        ->firstWhere('route_name', 'admin.production.quality.index');

    expect($inventoryReport['parent_path'])->toBe('المخزون / تقارير المخزون')
        ->and($productionQuality['parent_path'])->toBe('التصنيع والإنتاج / الجودة');
});

test('relocated reports keep breadcrumbs and recursive LTR and RTL rendering while prior nesting remains intact', function (): void {
    config()->set('erp.phase_mode', 'expanded');
    $admin = navigationAuditAdmin();

    app()->setLocale('en');
    $englishMenu = app(MenuService::class)->getMenu($admin);
    $englishTop = view('layouts.partials.menu.top-items', ['items' => $englishMenu, 'menuPath' => []])->render();
    $englishVertical = view('layouts.partials.menu.vertical-items', ['items' => $englishMenu, 'menuPath' => []])->render();
    $salesReportBreadcrumbs = app(BreadcrumbService::class)->forMenuRoute('admin.reports.sales.sales-orders.index');
    $fixedAssetBreadcrumbs = app(BreadcrumbService::class)->forMenuRoute('admin.fixed-assets.assets.index');

    app()->setLocale('ar');
    $arabicMenu = app(MenuService::class)->getMenu($admin);
    $arabicTop = view('layouts.partials.menu.top-items', ['items' => $arabicMenu, 'menuPath' => []])->render();
    $arabicVertical = view('layouts.partials.menu.vertical-items', ['items' => $arabicMenu, 'menuPath' => []])->render();

    expect(config('languages.available.en.dir'))->toBe('ltr')
        ->and(config('languages.available.ar.dir'))->toBe('rtl')
        ->and($englishTop)->toContain('Finance', 'Accounting &amp; Costing', 'Fixed Assets', 'Maintenance', 'Sales Reports', 'Sales Orders')
        ->and($englishVertical)->toContain('Finance', 'Accounting &amp; Costing', 'Fixed Assets', 'Maintenance', 'Sales Reports', 'Sales Orders')
        ->and($arabicTop)->toContain('المالية', 'الحسابات والتكاليف', 'الأصول الثابتة', 'الصيانة', 'تقارير المبيعات', 'أوامر المبيعات')
        ->and($arabicVertical)->toContain('المالية', 'الحسابات والتكاليف', 'الأصول الثابتة', 'الصيانة', 'تقارير المبيعات', 'أوامر المبيعات')
        ->and(collect($salesReportBreadcrumbs)->pluck('label')->all())->toBe(['Dashboard', 'Accounting & Costing', 'Financial Analytics Reports', 'Financial Analysis'])
        ->and(collect($fixedAssetBreadcrumbs)->pluck('label')->all())->toBe(['Dashboard', 'Accounting & Costing', 'Fixed Assets', 'Fixed Assets Register']);
});

test('inventory and sales reports use their owning modules without a top-level reports section', function (): void {
    config()->set('erp.phase_mode', 'expanded');
    $admin = navigationAuditAdmin();
    $menu = app(MenuService::class)->getMenu($admin);
    $records = collect(navigationAuditRecords($menu));

    expect(collect($menu)->pluck('label')->all())->not->toContain('reports')
        ->and($records->firstWhere('stable_path', 'inventory > item_data'))->not->toBeNull()
        ->and(collect($records->firstWhere('stable_path', 'inventory > inventory_module_reports')['children'] ?? [])->pluck('label')->all())->toContain(
            'inventory_stock_balance_inquiry',
            'inventory_operational_reports',
            'inventory_valuation_report',
            'inventory_sales_valuation_report',
        )
        ->and($records->where('route', 'admin.reports.customers.index'))->toHaveCount(1)
        ->and($records->firstWhere('route', 'admin.reports.customers.index')['label_path'])->toBe(['sales', 'sales_cycle_reports', 'customers_report']);
});
