<?php

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Maatwebsite\Excel\Facades\Excel;
use Modules\Accounting\Models\Account;
use Modules\Accounting\Models\JournalEntry;
use Modules\Auth\Models\Role;
use Modules\Core\Models\Branch;
use Modules\Core\Models\Company;
use Modules\Core\Models\Currency;
use Modules\Core\Models\FinancialPeriod;
use Modules\Core\Services\OperatingContextService;
use Modules\Core\Services\Reports\ReportPdfService;
use Modules\Finance\Exports\FinanceReportExport;
use Modules\Finance\Http\Controllers\FinanceReportController;
use Modules\Finance\Models\BankAccount;
use Modules\Finance\Models\Cashbox;
use Modules\Finance\Models\CashboxCount;
use Modules\Finance\Models\CashVoucher;
use Modules\Finance\Models\Cheque;
use Modules\Finance\Models\FundTransfer;
use Modules\Finance\Services\CashVoucherService;
use Modules\Finance\Services\FinanceReportService;
use Modules\Purchases\Models\PurchaseInvoice;
use Modules\Purchases\Models\PurchaseInvoicePaymentSchedule;
use Modules\Purchases\Models\Supplier;
use Modules\Sales\Models\Customer;
use Modules\Sales\Models\CustomerInvoice;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\PermissionRegistrar;

/** @return array<string, mixed> */
function financeReportFixture(object $test): array
{
    $company = Company::query()->create([
        'doc_number' => 9701, 'doc_num' => 'COMP-9701', 'name' => 'Finance Reports Company', 'status' => 'active', 'is_main' => true,
    ]);
    $branch = Branch::query()->create([
        'doc_number' => 9701, 'doc_num' => 'BR-9701', 'company_id' => $company->getKey(), 'name' => 'Main Branch', 'type' => 'main', 'status' => 'active',
    ]);
    $period = FinancialPeriod::query()->create([
        'doc_number' => 9701, 'doc_num' => 'FY-9701', 'company_id' => $company->getKey(), 'name' => 'FY 2026',
        'from_date' => '2026-01-01', 'to_date' => '2026-12-31', 'is_closed' => false, 'status' => 'active',
    ]);
    $currency = Currency::query()->create([
        'doc_number' => 9701, 'doc_num' => 'CUR-9701', 'company_id' => $company->getKey(), 'name' => 'Egyptian Pound',
        'name_en' => 'Egyptian Pound', 'code' => 'EGP', 'minor_unit_name' => 'Piastre', 'minor_unit_factor' => 100, 'is_main' => true, 'status' => 'active',
    ]);
    $accountOne = financeReportAccount($company, 9701, '111101', 'Main Cashbox Account');
    $accountTwo = financeReportAccount($company, 9702, '111102', 'Petty Cashbox Account');
    $counterAccount = financeReportAccount($company, 9799, '411999', 'Receipt Counter Account');
    $cashboxOne = Cashbox::query()->create([
        'doc_number' => 9701, 'doc_num' => 'CASH-9701', 'company_id' => $company->getKey(), 'name' => 'Main Cashbox',
        'branch_id' => $branch->getKey(), 'account_id' => $accountOne->getKey(), 'status' => 'active',
    ]);
    $cashboxTwo = Cashbox::query()->create([
        'doc_number' => 9702, 'doc_num' => 'CASH-9702', 'company_id' => $company->getKey(), 'name' => 'Petty Cashbox',
        'branch_id' => $branch->getKey(), 'account_id' => $accountTwo->getKey(), 'status' => 'active',
    ]);

    $receipt = CashVoucher::query()->create([
        'doc_number' => 9701, 'doc_num' => 'CRV-9701', 'company_id' => $company->getKey(), 'voucher_type' => CashVoucher::TypeReceipt,
        'voucher_date' => '2026-09-01', 'cashbox_id' => $cashboxOne->getKey(), 'currency_id' => $currency->getKey(),
        'exchange_rate' => 1, 'amount' => 100, 'amount_base' => 100, 'reason' => 'Approved receipt', 'status' => CashVoucher::StatusApproved,
    ]);
    $receiptJournal = JournalEntry::query()->create([
        'doc_number' => 9701, 'doc_num' => 'JE-9701', 'entry_date' => '2026-09-01', 'company_id' => $company->getKey(),
        'financial_period_id' => $period->getKey(), 'branch_id' => $branch->getKey(), 'currency_id' => $currency->getKey(),
        'exchange_rate' => 1, 'description' => 'Canonical generic receipt', 'source_type' => CashVoucherService::SourceReceipt,
        'source_id' => $receipt->getKey(), 'source_doc_num' => $receipt->doc_num, 'status' => JournalEntry::StatusPosted,
        'is_system_generated' => true, 'is_posted' => true, 'approved' => true,
    ]);
    $receiptJournal->lines()->createMany([
        ['line_no' => 1, 'account_id' => $accountOne->getKey(), 'debit_amount' => 100, 'credit_amount' => 0, 'branch_id' => $branch->getKey()],
        ['line_no' => 2, 'account_id' => $counterAccount->getKey(), 'debit_amount' => 0, 'credit_amount' => 100, 'branch_id' => $branch->getKey()],
    ]);
    CashVoucher::query()->create([
        'doc_number' => 9702, 'doc_num' => 'CRV-9702-DRAFT', 'company_id' => $company->getKey(), 'voucher_type' => CashVoucher::TypeReceipt,
        'voucher_date' => '2026-09-01', 'cashbox_id' => $cashboxOne->getKey(), 'currency_id' => $currency->getKey(),
        'exchange_rate' => 1, 'amount' => 999, 'amount_base' => 999, 'reason' => 'Draft receipt', 'status' => CashVoucher::StatusDraft,
    ]);
    FundTransfer::query()->create([
        'doc_number' => 9701, 'doc_num' => 'TRF-9701', 'company_id' => $company->getKey(), 'transfer_date' => '2026-09-02',
        'source_type' => FundTransfer::HolderCashbox, 'source_cashbox_id' => $cashboxOne->getKey(),
        'target_type' => FundTransfer::HolderCashbox, 'target_cashbox_id' => $cashboxTwo->getKey(),
        'source_currency_id' => $currency->getKey(), 'target_currency_id' => $currency->getKey(), 'source_amount' => 20,
        'exchange_rate' => 1, 'target_amount' => 20, 'source_amount_base' => 20, 'target_amount_base' => 20,
        'reason' => 'Cash replenishment', 'status' => FundTransfer::StatusApproved,
    ]);

    $session = [
        OperatingContextService::CompanyIdKey => $company->getKey(), OperatingContextService::CompanyDocNumKey => $company->doc_num,
        OperatingContextService::BranchIdKey => $branch->getKey(), OperatingContextService::BranchDocNumKey => $branch->doc_num,
        OperatingContextService::FinancialPeriodIdKey => $period->getKey(), OperatingContextService::FinancialPeriodDocNumKey => $period->doc_num,
    ];
    $test->withSession($session);
    request()->setLaravelSession(app('session.store'));
    request()->session()->put($session);

    return compact('company', 'branch', 'period', 'currency', 'cashboxOne', 'cashboxTwo');
}

function financeReportAccount(Company $company, int $number, string $code, string $name): Account
{
    return Account::query()->create([
        'doc_number' => $number, 'doc_num' => 'ACC-'.$number, 'company_id' => $company->getKey(), 'account_code' => $code,
        'name' => $name, 'name_en' => $name, 'level' => 1, 'account_type' => Account::TypeAsset,
        'statement_type' => Account::StatementFinancialPosition, 'normal_balance' => Account::BalanceDebit,
        'is_group' => false, 'is_postable' => true, 'status' => 'active',
    ]);
}

function financeReportActor(): User
{
    app(PermissionRegistrar::class)->forgetCachedPermissions();
    $permission = Permission::findOrCreate('reports.finance.view', 'web');
    $user = User::factory()->create(['locale' => 'en']);
    $user->givePermissionTo($permission);
    auth()->login($user);
    request()->setUserResolver(fn (): User => $user);

    return $user;
}

function financeDashboardCount(string $html, string $key): int
{
    preg_match('/data-operational-card="'.preg_quote($key, '/').'".*?data-operational-card-value[^>]*>\s*([0-9,]+)\s*</s', $html, $matches);

    return (int) str_replace(',', '', $matches[1] ?? '0');
}

function financeReportCount(string $html, string $key): int
{
    preg_match('/data-report-count="'.preg_quote($key, '/').'"[^>]*>\s*([0-9,]+)\s*</', $html, $matches);

    return (int) str_replace(',', '', $matches[1] ?? '0');
}

test('finance cashbox reports reconcile approved vouchers and both transfer legs without counting drafts', function (): void {
    $fixture = financeReportFixture($this);
    $actor = financeReportActor();
    $this->actingAs($actor);

    $service = app(FinanceReportService::class);
    $report = $service->report([
        'type' => FinanceReportService::CashboxBalances,
        'as_of_date' => '2026-09-30',
    ]);

    $main = $report['rows']->first(fn (array $row): bool => str_contains($row['cashbox'], $fixture['cashboxOne']->doc_num));
    $petty = $report['rows']->first(fn (array $row): bool => str_contains($row['cashbox'], $fixture['cashboxTwo']->doc_num));

    expect($main['receipts'])->toBe('100.0000')
        ->and($main['payments'])->toBe('20.0000')
        ->and($main['balance'])->toBe('80.0000')
        ->and($petty['receipts'])->toBe('20.0000')
        ->and($petty['payments'])->toBe('0.0000')
        ->and($petty['balance'])->toBe('20.0000');

    $statement = $service->report([
        'type' => FinanceReportService::CashboxStatement,
        'from_date' => '2026-09-01',
        'to_date' => '2026-09-30',
        'as_of_date' => '2026-09-30',
    ]);

    expect($statement['rows']->pluck('document')->all())
        ->toContain('CRV-9701', 'TRF-9701')
        ->not->toContain('CRV-9702-DRAFT');
});

test('finance report options exclude inactive or deleted holders while movement queries retain history', function (): void {
    $fixture = financeReportFixture($this);
    financeReportActor();
    $service = app(FinanceReportService::class);
    $bankGroup = financeReportAccount($fixture['company'], 9710, '111200', 'Historical Bank Group');
    $bankGroup->forceFill(['is_group' => true, 'is_postable' => false])->save();
    $bankSourceAccount = financeReportAccount($fixture['company'], 9711, '111201', 'Historical Bank Source Ledger');
    $bankTargetAccount = financeReportAccount($fixture['company'], 9712, '111202', 'Historical Bank Target Ledger');
    $bankSource = BankAccount::query()->create([
        'doc_number' => 9711,
        'doc_num' => 'BANK-9711',
        'company_id' => $fixture['company']->getKey(),
        'bank_id' => $bankGroup->getKey(),
        'account_id' => $bankSourceAccount->getKey(),
        'currency_id' => $fixture['currency']->getKey(),
        'account_name' => 'Historical Source Bank',
        'account_number' => '9711',
        'status' => 'active',
    ]);
    $bankTarget = BankAccount::query()->create([
        'doc_number' => 9712,
        'doc_num' => 'BANK-9712',
        'company_id' => $fixture['company']->getKey(),
        'bank_id' => $bankGroup->getKey(),
        'account_id' => $bankTargetAccount->getKey(),
        'currency_id' => $fixture['currency']->getKey(),
        'account_name' => 'Historical Target Bank',
        'account_number' => '9712',
        'status' => 'active',
    ]);
    FundTransfer::query()->create([
        'doc_number' => 9711,
        'doc_num' => 'TRF-BANK-9711',
        'company_id' => $fixture['company']->getKey(),
        'transfer_date' => '2026-09-03',
        'source_type' => FundTransfer::HolderBankAccount,
        'source_bank_account_id' => $bankSource->getKey(),
        'target_type' => FundTransfer::HolderBankAccount,
        'target_bank_account_id' => $bankTarget->getKey(),
        'source_currency_id' => $fixture['currency']->getKey(),
        'target_currency_id' => $fixture['currency']->getKey(),
        'source_amount' => 30,
        'exchange_rate' => 1,
        'target_amount' => 30,
        'source_amount_base' => 30,
        'target_amount_base' => 30,
        'reason' => 'Historical bank movement',
        'status' => FundTransfer::StatusApproved,
    ]);

    $fixture['cashboxOne']->delete();
    $bankSource->delete();
    $fixture['cashboxTwo']->update(['status' => 'inactive']);
    $bankTarget->update(['status' => 'inactive']);

    $options = $service->filterOptions();
    expect($options['cashboxes']->pluck('doc_num'))
        ->not->toContain($fixture['cashboxOne']->doc_num, $fixture['cashboxTwo']->doc_num)
        ->and($options['bank_accounts']->pluck('doc_num'))
        ->not->toContain($bankSource->doc_num, $bankTarget->doc_num);

    $selectedOptions = $service->filterOptions([
        'cashbox_doc_num' => $fixture['cashboxOne']->doc_num,
        'bank_account_doc_num' => $bankSource->doc_num,
    ]);
    expect($selectedOptions['cashboxes']->pluck('doc_num'))->toContain($fixture['cashboxOne']->doc_num)
        ->and($selectedOptions['bank_accounts']->pluck('doc_num'))->toContain($bankSource->doc_num);

    $cashboxStatement = $service->report([
        'type' => FinanceReportService::CashboxStatement,
        'from_date' => '2026-09-01',
        'to_date' => '2026-09-30',
        'cashbox_doc_num' => $fixture['cashboxOne']->doc_num,
    ]);
    $bankStatement = $service->report([
        'type' => FinanceReportService::BankAccountStatement,
        'from_date' => '2026-09-01',
        'to_date' => '2026-09-30',
        'bank_account_doc_num' => $bankSource->doc_num,
    ]);

    expect($cashboxStatement['rows']->pluck('document'))->toContain('CRV-9701', 'TRF-9701')
        ->and($bankStatement['rows']->pluck('document'))->toContain('TRF-BANK-9711');

    $this->actingAs(auth()->user())
        ->get(route('admin.reports.finance.index', [
            'type' => FinanceReportService::CashboxStatement,
            'cashbox_doc_num' => $fixture['cashboxOne']->doc_num,
        ]))
        ->assertOk()
        ->assertSee($fixture['cashboxOne']->doc_num);
});

test('finance reports default to the operating branch and reject a branch outside the user scope', function (): void {
    $fixture = financeReportFixture($this);
    $actor = financeReportActor();
    $otherBranch = Branch::query()->create([
        'doc_number' => 9751, 'doc_num' => 'BR-9751', 'company_id' => $fixture['company']->getKey(),
        'name' => 'Restricted Branch', 'type' => 'branch', 'status' => 'active',
    ]);
    $otherAccount = financeReportAccount($fixture['company'], 9751, '111751', 'Restricted Cashbox Account');
    $otherCashbox = Cashbox::query()->create([
        'doc_number' => 9751, 'doc_num' => 'CASH-9751', 'company_id' => $fixture['company']->getKey(),
        'name' => 'Restricted Cashbox', 'branch_id' => $otherBranch->getKey(),
        'account_id' => $otherAccount->getKey(), 'status' => 'active',
    ]);
    foreach ([
        ['number' => 9752, 'document' => 'CRV-OTHER-APPROVED', 'status' => CashVoucher::StatusApproved],
        ['number' => 9753, 'document' => 'CRV-OTHER-DRAFT', 'status' => CashVoucher::StatusDraft],
    ] as $voucher) {
        CashVoucher::query()->create([
            'doc_number' => $voucher['number'], 'doc_num' => $voucher['document'],
            'company_id' => $fixture['company']->getKey(), 'voucher_type' => CashVoucher::TypeReceipt,
            'voucher_date' => '2026-09-01', 'cashbox_id' => $otherCashbox->getKey(),
            'currency_id' => $fixture['currency']->getKey(), 'exchange_rate' => 1,
            'amount' => 50, 'amount_base' => 50, 'reason' => 'Restricted branch voucher',
            'status' => $voucher['status'],
        ]);
    }
    $role = Role::query()->create([
        'name' => 'finance-report-scope-9751', 'guard_name' => 'web', 'doc_number' => 9751,
        'doc_num' => 'Role-09751', 'company_access_restricted' => true,
        'branch_access_restricted' => true, 'financial_period_access_restricted' => true,
    ]);
    $actor->assignRole($role);
    DB::table('role_company_access')->insert(['role_id' => $role->getKey(), 'company_id' => $fixture['company']->getKey(), 'created_at' => now(), 'updated_at' => now()]);
    DB::table('role_branch_access')->insert(['role_id' => $role->getKey(), 'branch_id' => $fixture['branch']->getKey(), 'created_at' => now(), 'updated_at' => now()]);
    DB::table('role_financial_period_access')->insert(['role_id' => $role->getKey(), 'financial_period_id' => $fixture['period']->getKey(), 'created_at' => now(), 'updated_at' => now()]);

    app(PermissionRegistrar::class)->forgetCachedPermissions();
    request()->setUserResolver(fn (): User => $actor);

    $filterRequest = Request::create('/reports', 'GET', [
        'type' => FinanceReportService::CashboxBalances,
    ]);
    $filterRequest->setLaravelSession(app('session.store'));
    $filterRequest->setUserResolver(fn (): User => $actor);
    $filters = app(FinanceReportService::class)->filters($filterRequest);
    $options = app(FinanceReportService::class)->filterOptions($filters);

    expect($filters['branch_id'])->toBe($fixture['branch']->getKey())
        ->and($options['cashboxes']->pluck('doc_num'))->not->toContain($otherCashbox->doc_num);

    foreach ([
        FinanceReportService::CashVouchers => ['CRV-9701', 'CRV-OTHER-APPROVED'],
        FinanceReportService::UnapprovedDocuments => ['CRV-9702-DRAFT', 'CRV-OTHER-DRAFT'],
    ] as $type => [$visibleDocument, $restrictedDocument]) {
        $reportRequest = Request::create('/reports', 'GET', ['type' => $type]);
        $reportRequest->setLaravelSession(app('session.store'));
        $reportRequest->setUserResolver(fn (): User => $actor);
        $report = app(FinanceReportService::class)->report(app(FinanceReportService::class)->filters($reportRequest));

        expect($report['rows']->pluck('document'))->toContain($visibleDocument)
            ->not->toContain($restrictedDocument);
    }

    $this->actingAs($actor)
        ->getJson(route('admin.reports.finance.index', [
            'type' => FinanceReportService::CashboxBalances,
            'branch_id' => $otherBranch->getKey(),
        ]))
        ->assertUnprocessable()
        ->assertJsonValidationErrors('branch_id');
});

test('due cheque filters use stable keys while rendering localized labels', function (): void {
    Carbon::setTestNow(Carbon::create(2026, 9, 17, 10));
    $fixture = financeReportFixture($this);
    financeReportActor();

    foreach ([
        ['number' => 9761, 'document' => 'CHQ-OVERDUE', 'due' => '2026-09-16', 'state' => 'overdue'],
        ['number' => 9762, 'document' => 'CHQ-TODAY', 'due' => '2026-09-17', 'state' => 'due_today'],
        ['number' => 9763, 'document' => 'CHQ-UPCOMING', 'due' => '2026-09-18', 'state' => 'upcoming'],
    ] as $cheque) {
        Cheque::query()->create([
            'doc_number' => $cheque['number'], 'doc_num' => $cheque['document'],
            'company_id' => $fixture['company']->getKey(), 'cheque_type' => Cheque::TypeReceived,
            'cheque_number' => (string) $cheque['number'], 'cheque_date' => '2026-09-01',
            'due_date' => $cheque['due'], 'currency_id' => $fixture['currency']->getKey(),
            'amount' => 10, 'amount_base' => 10, 'reason' => 'Due-state regression',
            'status' => Cheque::StatusReceived,
        ]);
    }

    foreach (['en', 'ar'] as $locale) {
        app()->setLocale($locale);
        foreach (['overdue' => 'CHQ-OVERDUE', 'due_today' => 'CHQ-TODAY', 'upcoming' => 'CHQ-UPCOMING'] as $state => $document) {
            $rows = app(FinanceReportService::class)->report([
                'type' => FinanceReportService::DueCheques,
                'as_of_date' => '2026-09-17',
                'to_date' => '2026-09-30',
                'due_state' => $state,
            ])['rows'];

            expect($rows->pluck('document')->all())->toBe([$document])
                ->and($rows->sole()['due_state'])->toBe(__("finance_reports.values.{$state}"));
        }
    }
});

test('cashbox statement defaults its through date and renders without explicit date filters', function (): void {
    Carbon::setTestNow(Carbon::create(2026, 9, 30, 10));

    try {
        $fixture = financeReportFixture($this);
        $actor = financeReportActor();
        $expectedExportFilters = [
            'type' => FinanceReportService::CashboxStatement,
            'to_date' => '2026-09-30',
            'branch_id' => $fixture['branch']->getKey(),
        ];

        $response = $this->actingAs($actor)->get(route('admin.reports.finance.index', [
            'type' => FinanceReportService::CashboxStatement,
        ]));

        $response->assertOk()
            ->assertSee(__('finance_reports.types.cashbox_statement.title'))
            ->assertSee('id="finance-report-to"', false)
            ->assertSee('value="2026-09-30"', false)
            ->assertSee(__('finance_reports.filters.to_date').':')
            ->assertSee(route('admin.reports.finance.export.excel', $expectedExportFilters))
            ->assertSee(route('admin.reports.finance.export.csv', $expectedExportFilters))
            ->assertSee(route('admin.reports.finance.export.pdf', $expectedExportFilters))
            ->assertSee('CRV-9701')
            ->assertDontSee('CRV-9702-DRAFT');

    } finally {
        Carbon::setTestNow();
    }
});

test('finance report screen uses the shared report toolbar filter panel and localized date controls', function (): void {
    $fixture = financeReportFixture($this);
    $actor = financeReportActor();
    $parameters = [
        'type' => FinanceReportService::CashboxStatement,
        'from_date' => '2026-09-01',
        'to_date' => '2026-09-30',
        'cashbox_doc_num' => $fixture['cashboxOne']->doc_num,
    ];
    $expectedExportFilters = [...$parameters, 'branch_id' => $fixture['branch']->getKey()];

    $response = $this->actingAs($actor)
        ->get(route('admin.reports.finance.index', $parameters))
        ->assertOk()
        ->assertSee('admin-report-page', false)
        ->assertSee('report-actions-toolbar', false)
        ->assertSee('data-bs-target="#finance-report-filters"', false)
        ->assertSee('id="finance-report-filters"', false)
        ->assertSee(route('admin.reports.finance.export.excel', $expectedExportFilters))
        ->assertSee(route('admin.reports.finance.export.csv', $expectedExportFilters))
        ->assertSee(route('admin.reports.finance.export.pdf', $expectedExportFilters));

    $html = $response->getContent();
    $balanceHtml = $this->actingAs($actor)
        ->get(route('admin.reports.finance.index', [
            'type' => FinanceReportService::CashboxBalances,
            'as_of_date' => '2026-09-30',
        ]))
        ->assertOk()
        ->getContent();

    expect(substr_count($html, 'js-report-export'))->toBe(3)
        ->and(substr_count($html, 'fas fa-download me-1'))->toBe(1)
        ->and(preg_match('/<input(?=[^>]*id="finance-report-from")(?=[^>]*name="from_date")(?=[^>]*type="text")(?=[^>]*js-date-picker)[^>]*>/', $html))->toBe(1)
        ->and(preg_match('/<input(?=[^>]*id="finance-report-to")(?=[^>]*name="to_date")(?=[^>]*type="text")(?=[^>]*js-date-picker)[^>]*>/', $html))->toBe(1)
        ->and(preg_match('/<input(?=[^>]*id="finance-report-as-of")(?=[^>]*name="as_of_date")(?=[^>]*type="text")(?=[^>]*js-date-picker)[^>]*>/', $balanceHtml))->toBe(1);
});

test('finance spreadsheet exports retain report rows and append matching currency totals in both formats', function (): void {
    $fixture = financeReportFixture($this);
    $actor = financeReportActor();
    $filters = [
        'type' => FinanceReportService::CashboxStatement,
        'from_date' => '2026-09-01',
        'to_date' => '2026-09-30',
        'cashbox_doc_num' => $fixture['cashboxOne']->doc_num,
        'branch_id' => $fixture['branch']->getKey(),
    ];
    $report = app(FinanceReportService::class)->report($filters);
    $originalRows = $report['rows']->values();
    $export = new FinanceReportExport($report);
    $exportRows = $export->collection();
    $totalRows = $exportRows->where('_is_total', true)->values();
    $currencyTotals = $report['currency_totals']['EGP'];
    $totalRow = $totalRows->sole();

    expect($exportRows->take($originalRows->count())->all())->toBe($originalRows->all())
        ->and($totalRows)->toHaveCount(count($report['currency_totals']))
        ->and($totalRow['date'])->toBe(__('common.total'))
        ->and($totalRow['currency'])->toBe('EGP')
        ->and($totalRow['receipt'])->toBe($currencyTotals[__('finance_reports.columns.receipt')])
        ->and($totalRow['payment'])->toBe($currencyTotals[__('finance_reports.columns.payment')])
        ->and($totalRow['balance'])->toBe($currencyTotals[__('finance_reports.columns.balance')]);

    $mappedTotal = array_combine($export->headings(), $export->map($totalRow));
    expect($mappedTotal[__('finance_reports.columns.date')])->toBe(__('common.total'))
        ->and($mappedTotal[__('finance_reports.columns.currency')])->toBe('EGP')
        ->and($mappedTotal[__('finance_reports.columns.balance')])->toBe($currencyTotals[__('finance_reports.columns.balance')]);

    Excel::fake();
    $structures = [];
    $structure = fn (FinanceReportExport $financeExport): array => [
        'headings' => $financeExport->headings(),
        'rows' => $financeExport->collection()
            ->map(fn (array $row): array => $financeExport->map($row))
            ->all(),
    ];

    $this->actingAs($actor)->get(route('admin.reports.finance.export.excel', $filters))->assertOk();
    Excel::assertDownloaded('finance-cashbox_statement.xlsx', function (FinanceReportExport $financeExport) use (&$structures, $structure): bool {
        $structures['xlsx'] = $structure($financeExport);

        return true;
    });

    $this->actingAs($actor)->get(route('admin.reports.finance.export.csv', $filters))->assertOk();
    Excel::assertDownloaded('finance-cashbox_statement.csv', function (FinanceReportExport $financeExport) use (&$structures, $structure): bool {
        $structures['csv'] = $structure($financeExport);

        return true;
    });

    expect($structures['xlsx'])->toBe($structures['csv']);
});

test('finance PDF view renders criteria currency totals and cashbox statement rows with common report structure', function (): void {
    $fixture = financeReportFixture($this);
    $actor = financeReportActor();
    $originalLocale = app()->getLocale();

    try {
        foreach (['en' => 'ltr', 'ar' => 'rtl'] as $locale => $direction) {
            app()->setLocale($locale);
            $report = app(FinanceReportService::class)->report([
                'type' => FinanceReportService::CashboxStatement,
                'from_date' => '2026-09-01',
                'to_date' => '2026-09-30',
                'cashbox_doc_num' => $fixture['cashboxOne']->doc_num,
            ]);

            $html = view('reports.finance', [
                'report' => $report,
                'direction' => $direction,
            ])->render();

            expect($html)
                ->toContain('<html lang="'.$locale.'" dir="'.$direction.'">')
                ->toContain('report-filter-summary')
                ->toContain('document-totals-table finance-report-totals')
                ->toContain('report-table finance-report-table')
                ->toContain(__('finance_reports.types.cashbox_statement.title'))
                ->toContain(__('finance_reports.active_filters'))
                ->toContain($fixture['cashboxOne']->doc_num)
                ->toContain('CRV-9701')
                ->toContain('TRF-9701')
                ->toContain('class="text-end" dir="ltr"')
                ->not->toContain('CRV-9702-DRAFT');
        }
    } finally {
        app()->setLocale($originalLocale);
    }

    $pdfResponse = $this->actingAs($actor)->get(route('admin.reports.finance.export.pdf', [
        'type' => FinanceReportService::CashboxStatement,
        'from_date' => '2026-09-01',
        'to_date' => '2026-09-30',
        'cashbox_doc_num' => $fixture['cashboxOne']->doc_num,
    ]));

    $pdfResponse->assertOk()->assertHeader('content-type', 'application/pdf');
    expect($pdfResponse->getContent())->toStartWith('%PDF');

    $pdf = Mockery::mock(ReportPdfService::class);
    $pdf->shouldReceive('stream')->once()->withArgs(function (string $view, array $data, string $filename, string $orientation): bool {
        expect($view)->toBe('reports.finance')
            ->and($data['title'])->toBe($data['report']['title'])
            ->and($filename)->toBe('finance-cashbox_statement.pdf')
            ->and($orientation)->toBe('L');

        return true;
    })->andReturn(response('%PDF-1.4', 200, ['Content-Type' => 'application/pdf']));
    $this->app->instance(ReportPdfService::class, $pdf);

    $this->actingAs($actor)->get(route('admin.reports.finance.export.pdf', [
        'type' => FinanceReportService::CashboxStatement,
        'from_date' => '2026-09-01',
        'to_date' => '2026-09-30',
        'cashbox_doc_num' => $fixture['cashboxOne']->doc_num,
    ]))->assertOk()->assertHeader('content-type', 'application/pdf');
});

test('legacy finance report route renders the actual unified report and unsupported guarantee navigation is absent', function (): void {
    financeReportFixture($this);
    $actor = financeReportActor();

    $this->actingAs($actor)
        ->get(route('admin.reports.finance.index', ['type' => FinanceReportService::CashboxStatement, 'from_date' => '2026-09-01', 'to_date' => '2026-09-30']))
        ->assertOk()
        ->assertSee(__('finance_reports.types.cashbox_statement.title'))
        ->assertSee('CRV-9701')
        ->assertDontSee('CRV-9702-DRAFT')
        ->assertSee(route('admin.reports.finance.export.excel'), false);

    expect(Route::has('admin.reports.finance.guarantee-cheques.index'))->toBeFalse()
        ->and(FinanceReportService::types())->not->toContain('guarantee_cheques');

    $this->actingAs($actor)
        ->getJson(route('admin.reports.finance.cashbox-balances.data', ['as_of_date' => '2026-09-30']))
        ->assertOk()
        ->assertJsonPath('recordsTotal', 2)
        ->assertJsonFragment(['balance' => '80.0000']);
});

test('finance reports only retain and render filters that affect their selected mode', function (): void {
    financeReportFixture($this);
    $actor = financeReportActor();
    $request = Request::create('/admin/reports/finance', 'GET', [
        'type' => FinanceReportService::AdvancesAllocations,
        'from_date' => '2026-09-01',
        'as_of_date' => '2026-09-30',
        'status' => 'draft',
        'cashbox_doc_num' => 'CASH-9701',
    ]);

    $filters = app(FinanceReportService::class)->filters($request);

    expect($filters)->toBe([
        'type' => FinanceReportService::AdvancesAllocations,
        'from_date' => '2026-09-01',
    ]);

    $this->actingAs($actor)
        ->get(route('admin.reports.finance.advances-allocations.index', [
            'as_of_date' => '2026-09-30',
            'status' => 'draft',
        ]))
        ->assertOk()
        ->assertDontSee('name="as_of_date"', false)
        ->assertDontSee('name="status"', false)
        ->assertDontSee(__('finance_reports.filters.as_of_date').':');
});

test('named finance report routes lock their report mode and cashbox count opens a live count worksheet', function (): void {
    $fixture = financeReportFixture($this);
    $actor = financeReportActor();
    $permission = Permission::findOrCreate('finance.cashbox_count.view', 'web');
    $actor->givePermissionTo($permission);
    expect(Route::getRoutes()->getByName('admin.reports.finance.cashbox-balances.index')?->getActionName())
        ->toBe(FinanceReportController::class.'@index');
    $zeroAccount = financeReportAccount($fixture['company'], 9703, '111103', 'Zero Cashbox Account');
    Cashbox::query()->create([
        'doc_number' => 9703,
        'doc_num' => 'CASH-9703',
        'company_id' => $fixture['company']->getKey(),
        'name' => 'Zero Cashbox',
        'branch_id' => $fixture['branch']->getKey(),
        'account_id' => $zeroAccount->getKey(),
        'status' => 'active',
    ]);
    $otherBranch = Branch::query()->create([
        'doc_number' => 9702,
        'doc_num' => 'BR-9702',
        'company_id' => $fixture['company']->getKey(),
        'name' => 'Other Branch',
        'type' => 'branch',
        'status' => 'active',
    ]);
    $otherAccount = financeReportAccount($fixture['company'], 9704, '111104', 'Other Branch Cashbox Account');
    Cashbox::query()->create([
        'doc_number' => 9704,
        'doc_num' => 'CASH-9704',
        'company_id' => $fixture['company']->getKey(),
        'name' => 'Other Branch Cashbox',
        'branch_id' => $otherBranch->getKey(),
        'account_id' => $otherAccount->getKey(),
        'status' => 'active',
    ]);

    $this->actingAs($actor)
        ->get(route('admin.reports.finance.cashbox-balances.index', [
            'type' => 'guarantee_cheques',
            'as_of_date' => '2026-09-30',
        ]))
        ->assertOk()
        ->assertSee(__('finance_reports.types.cashbox_balances.title'))
        ->assertSee('name="type"', false)
        ->assertSee('value="cashbox_balances"', false)
        ->assertDontSee('value="guarantee_cheques" selected', false)
        ->assertSee(route('admin.reports.finance.export.excel', [
            'type' => FinanceReportService::CashboxBalances,
            'as_of_date' => '2026-09-30',
            'branch_id' => $fixture['branch']->getKey(),
        ]))
        ->assertSee('80');

    $this->actingAs($actor)
        ->get(route('admin.finance.cashbox-count.index', ['as_of_date' => '2026-09-30']))
        ->assertOk()
        ->assertSee(__('cashbox_count.title'))
        ->assertSee('data-cashbox-count', false)
        ->assertSee('Main Cashbox')
        ->assertSee('Zero Cashbox')
        ->assertDontSee('Other Branch Cashbox')
        ->assertSee('80');

    $this->actingAs($actor)
        ->getJson(route('admin.finance.cashbox-count.data', ['as_of_date' => '2026-09-30', 'draw' => 3]))
        ->assertOk()
        ->assertJsonPath('draw', 3)
        ->assertJsonPath('recordsTotal', 3)
        ->assertJsonFragment(['balance' => '80.0000'])
        ->assertJsonFragment(['cashbox' => 'CASH-9703 / Zero Cashbox', 'balance' => '0.0000'])
        ->assertJsonMissing(['cashbox' => 'CASH-9704 / Other Branch Cashbox']);
});

test('each named finance report honors its own generated permission', function (string $routeName, string $permission, string $titleKey): void {
    financeReportFixture($this);
    $actor = User::factory()->create();
    $actor->givePermissionTo(Permission::findOrCreate($permission, 'web'));

    $this->actingAs($actor)
        ->get(route($routeName, ['from_date' => '2026-01-01']))
        ->assertOk()
        ->assertSee(__($titleKey))
        ->assertSee('action="'.route($routeName).'"', false);
})->with([
    ['admin.reports.finance.cash-vouchers.index', 'reports.finance.cash_vouchers.view', 'finance_reports.types.cash_vouchers.title'],
    ['admin.reports.finance.bank-reconciliation.index', 'reports.finance.bank_reconciliation.view', 'finance_reports.types.bank_reconciliation.title'],
    ['admin.reports.finance.received-cheques.index', 'reports.finance.received_cheques.view', 'finance_reports.types.received_cheques.title'],
    ['admin.reports.finance.cleared-cheques.index', 'reports.finance.cleared_cheques.view', 'finance_reports.types.cleared_cheques.title'],
    ['admin.reports.finance.advances-allocations.index', 'reports.finance.advances_allocations.view', 'finance_reports.types.advances_allocations.title'],
    ['admin.reports.finance.unapproved-documents.index', 'reports.finance.unapproved_documents.view', 'finance_reports.types.unapproved_documents.title'],
]);

test('financial exception cards reuse scoped aging and cheque reports without terminal overlap', function (): void {
    Carbon::setTestNow(Carbon::create(2026, 9, 17, 10));
    $fixture = financeReportFixture($this);
    $actor = financeReportActor();
    $customer = Customer::query()->create([
        'doc_number' => 9710, 'doc_num' => 'CUS-9710', 'company_id' => $fixture['company']->getKey(),
        'name' => 'Dashboard Customer', 'status' => 'active',
    ]);
    $supplier = Supplier::query()->create([
        'doc_number' => 9710, 'doc_num' => 'SUP-9710', 'company_id' => $fixture['company']->getKey(),
        'name' => 'Dashboard Supplier', 'status' => 'active',
    ]);

    $overdueReceivable = CustomerInvoice::query()->create([
        'doc_number' => 9710, 'doc_num' => 'SINV-OVERDUE', 'company_id' => $fixture['company']->getKey(),
        'financial_period_id' => $fixture['period']->getKey(), 'branch_id' => $fixture['branch']->getKey(),
        'customer_id' => $customer->getKey(), 'invoice_date' => '2026-08-01', 'due_date' => '2026-09-01',
        'currency_id' => $fixture['currency']->getKey(), 'total_amount' => 100, 'remaining_amount' => 60,
        'status' => CustomerInvoice::StatusPosted, 'posting_status' => CustomerInvoice::StatusPosted,
        'document_type' => CustomerInvoice::TypeInvoice,
    ]);
    $overdueReceivable->paymentSchedules()->create([
        'sequence' => 1, 'due_date' => '2026-09-01', 'amount' => 100, 'collected_amount' => 40, 'credited_amount' => 0,
    ]);
    $futureReceivable = CustomerInvoice::query()->create([
        'doc_number' => 9711, 'doc_num' => 'SINV-FUTURE', 'company_id' => $fixture['company']->getKey(),
        'financial_period_id' => $fixture['period']->getKey(), 'branch_id' => $fixture['branch']->getKey(),
        'customer_id' => $customer->getKey(), 'invoice_date' => '2026-09-01', 'due_date' => '2026-10-01',
        'currency_id' => $fixture['currency']->getKey(), 'total_amount' => 100, 'remaining_amount' => 100,
        'status' => CustomerInvoice::StatusPosted, 'posting_status' => CustomerInvoice::StatusPosted,
        'document_type' => CustomerInvoice::TypeInvoice,
    ]);
    $futureReceivable->paymentSchedules()->create([
        'sequence' => 1, 'due_date' => '2026-10-01', 'amount' => 100, 'collected_amount' => 0, 'credited_amount' => 0,
    ]);
    $dueReceivable = CustomerInvoice::query()->create([
        'doc_number' => 9712, 'doc_num' => 'SINV-DUE-TODAY', 'company_id' => $fixture['company']->getKey(),
        'financial_period_id' => $fixture['period']->getKey(), 'branch_id' => $fixture['branch']->getKey(),
        'customer_id' => $customer->getKey(), 'invoice_date' => '2026-09-01', 'due_date' => '2026-09-17',
        'currency_id' => $fixture['currency']->getKey(), 'total_amount' => 30, 'remaining_amount' => 30,
        'status' => CustomerInvoice::StatusPosted, 'posting_status' => CustomerInvoice::StatusPosted,
        'document_type' => CustomerInvoice::TypeInvoice,
    ]);
    $dueReceivable->paymentSchedules()->create([
        'sequence' => 1, 'due_date' => '2026-09-17', 'amount' => 30, 'collected_amount' => 0, 'credited_amount' => 0,
    ]);
    $overduePayable = PurchaseInvoice::query()->create([
        'doc_number' => 9710, 'doc_num' => 'PINV-OVERDUE', 'company_id' => $fixture['company']->getKey(),
        'financial_period_id' => $fixture['period']->getKey(), 'branch_id' => $fixture['branch']->getKey(),
        'supplier_id' => $supplier->getKey(), 'invoice_date' => '2026-08-01',
        'currency_id' => $fixture['currency']->getKey(), 'total_amount' => 80, 'remaining_amount' => 50,
        'status' => PurchaseInvoice::StatusApproved, 'payment_status' => 'partially_paid',
    ]);
    $overduePayable->paymentSchedules()->create([
        'company_id' => $fixture['company']->getKey(), 'financial_period_id' => $fixture['period']->getKey(),
        'line_number' => 1, 'due_date' => '2026-09-01', 'amount' => 80, 'paid_amount' => 30,
        'credited_amount' => 0, 'status' => PurchaseInvoicePaymentSchedule::StatusPartiallyPaid,
    ]);
    $futurePayable = PurchaseInvoice::query()->create([
        'doc_number' => 9711, 'doc_num' => 'PINV-FUTURE', 'company_id' => $fixture['company']->getKey(),
        'financial_period_id' => $fixture['period']->getKey(), 'branch_id' => $fixture['branch']->getKey(),
        'supplier_id' => $supplier->getKey(), 'invoice_date' => '2026-09-01',
        'currency_id' => $fixture['currency']->getKey(), 'total_amount' => 80, 'remaining_amount' => 80,
        'status' => PurchaseInvoice::StatusApproved, 'payment_status' => 'unpaid',
    ]);
    $futurePayable->paymentSchedules()->create([
        'company_id' => $fixture['company']->getKey(), 'financial_period_id' => $fixture['period']->getKey(),
        'line_number' => 1, 'due_date' => '2026-10-01', 'amount' => 80, 'paid_amount' => 0,
        'credited_amount' => 0, 'status' => PurchaseInvoicePaymentSchedule::StatusScheduled,
    ]);
    $duePayable = PurchaseInvoice::query()->create([
        'doc_number' => 9712, 'doc_num' => 'PINV-DUE-TODAY', 'company_id' => $fixture['company']->getKey(),
        'financial_period_id' => $fixture['period']->getKey(), 'branch_id' => $fixture['branch']->getKey(),
        'supplier_id' => $supplier->getKey(), 'invoice_date' => '2026-09-01',
        'currency_id' => $fixture['currency']->getKey(), 'total_amount' => 20, 'remaining_amount' => 20,
        'status' => PurchaseInvoice::StatusApproved, 'payment_status' => 'unpaid',
    ]);
    $duePayable->paymentSchedules()->create([
        'company_id' => $fixture['company']->getKey(), 'financial_period_id' => $fixture['period']->getKey(),
        'line_number' => 1, 'due_date' => '2026-09-17', 'amount' => 20, 'paid_amount' => 0,
        'credited_amount' => 0, 'status' => PurchaseInvoicePaymentSchedule::StatusScheduled,
    ]);

    foreach ([
        ['number' => 9710, 'document' => 'CHQ-DUE', 'status' => Cheque::StatusReceived, 'due' => '2026-09-17'],
        ['number' => 9711, 'document' => 'CHQ-RETURNED', 'status' => Cheque::StatusReturned, 'due' => '2026-09-10'],
        ['number' => 9712, 'document' => 'CHQ-CLEARED', 'status' => Cheque::StatusCleared, 'due' => '2026-09-10'],
    ] as $cheque) {
        Cheque::query()->create([
            'doc_number' => $cheque['number'], 'doc_num' => $cheque['document'], 'company_id' => $fixture['company']->getKey(),
            'cheque_type' => Cheque::TypeReceived, 'cheque_number' => (string) $cheque['number'],
            'cheque_date' => '2026-08-01', 'due_date' => $cheque['due'], 'currency_id' => $fixture['currency']->getKey(),
            'amount' => 25, 'amount_base' => 25, 'reason' => 'Dashboard exception fixture', 'status' => $cheque['status'],
        ]);
    }
    $otherCompany = Company::query()->create([
        'doc_number' => 9799, 'doc_num' => 'COMP-9799', 'name' => 'Excluded Finance Company', 'status' => 'active', 'is_main' => false,
    ]);
    $otherCurrency = Currency::query()->create([
        'doc_number' => 9799, 'doc_num' => 'CUR-9799', 'company_id' => $otherCompany->getKey(), 'name' => 'Excluded Currency',
        'name_en' => 'Excluded Currency', 'code' => 'XFC', 'minor_unit_name' => 'Unit', 'minor_unit_factor' => 100, 'is_main' => true, 'status' => 'active',
    ]);
    Cheque::query()->create([
        'doc_number' => 9799, 'doc_num' => 'CHQ-OTHER-COMPANY', 'company_id' => $otherCompany->getKey(),
        'cheque_type' => Cheque::TypeReceived, 'cheque_number' => '9799', 'cheque_date' => '2026-08-01',
        'due_date' => '2026-09-17', 'currency_id' => $otherCurrency->getKey(), 'amount' => 25, 'amount_base' => 25,
        'reason' => 'Wrong-company exclusion fixture', 'status' => Cheque::StatusReceived,
    ]);

    $base = [
        'as_of_date' => '2026-09-17', 'branch_id' => $fixture['branch']->getKey(),
        'financial_period_id' => $fixture['period']->getKey(),
    ];
    $service = app(FinanceReportService::class);
    $receivables = $service->report([...$base, 'type' => FinanceReportService::CustomerAging, 'due_state' => 'due_or_overdue']);
    $payables = $service->report([...$base, 'type' => FinanceReportService::SupplierAging, 'due_state' => 'due_or_overdue']);
    $dueCheques = $service->report([...$base, 'type' => FinanceReportService::DueCheques, 'to_date' => '2026-09-17']);
    $returnedCheques = $service->report([...$base, 'type' => FinanceReportService::ReturnedCheques]);
    $pendingApprovals = $service->report([...$base, 'type' => FinanceReportService::UnapprovedDocuments]);

    expect($receivables['rows']->pluck('document')->all())->toBe(['SINV-OVERDUE', 'SINV-DUE-TODAY'])
        ->and($payables['rows']->pluck('document')->all())->toBe(['PINV-OVERDUE', 'PINV-DUE-TODAY'])
        ->and($service->report([...$base, 'type' => FinanceReportService::CustomerAging, 'due_state' => 'due'])['rows']->pluck('document')->all())->toBe(['SINV-DUE-TODAY'])
        ->and($service->report([...$base, 'type' => FinanceReportService::SupplierAging, 'due_state' => 'due'])['rows']->pluck('document')->all())->toBe(['PINV-DUE-TODAY'])
        ->and($dueCheques['rows']->pluck('document')->all())->toBe(['CHQ-DUE'])
        ->and($returnedCheques['rows']->pluck('document')->all())->toBe(['CHQ-RETURNED'])
        ->and($pendingApprovals['rows']->pluck('document')->all())->toBe(['CRV-9702-DRAFT']);

    $dashboard = $this->actingAs($actor)->get(route('dashboard'))->assertOk()->getContent();
    $receivablesReport = $this->actingAs($actor)->get(route('admin.reports.finance.index', [...$base, 'type' => FinanceReportService::CustomerAging, 'due_state' => 'due_or_overdue']))->assertOk()->getContent();
    $payablesReport = $this->actingAs($actor)->get(route('admin.reports.finance.index', [...$base, 'type' => FinanceReportService::SupplierAging, 'due_state' => 'due_or_overdue']))->assertOk()->getContent();
    $dueChequesReport = $this->actingAs($actor)->get(route('admin.reports.finance.index', [...$base, 'type' => FinanceReportService::DueCheques, 'to_date' => '2026-09-17']))->assertOk()->getContent();
    $returnedChequesReport = $this->actingAs($actor)->get(route('admin.reports.finance.index', [...$base, 'type' => FinanceReportService::ReturnedCheques]))->assertOk()->getContent();
    $pendingApprovalsReport = $this->actingAs($actor)->get(route('admin.reports.finance.index', [...$base, 'type' => FinanceReportService::UnapprovedDocuments]))->assertOk()->getContent();
    expect(financeDashboardCount($dashboard, 'pending_finance_approvals'))->toBe(1)
        ->and(financeDashboardCount($dashboard, 'pending_finance_approvals'))->toBe(financeReportCount($pendingApprovalsReport, 'pending_finance_approvals'))
        ->and(financeDashboardCount($dashboard, 'due_receivables'))->toBe($receivables['rows']->count())
        ->and(financeDashboardCount($dashboard, 'due_receivables'))->toBe(financeReportCount($receivablesReport, 'due_receivables'))
        ->and(financeDashboardCount($dashboard, 'due_payables'))->toBe($payables['rows']->count())
        ->and(financeDashboardCount($dashboard, 'due_payables'))->toBe(financeReportCount($payablesReport, 'due_payables'))
        ->and(financeDashboardCount($dashboard, 'due_cheques'))->toBe($dueCheques['rows']->count())
        ->and(financeDashboardCount($dashboard, 'due_cheques'))->toBe(financeReportCount($dueChequesReport, 'due_cheques'))
        ->and(financeDashboardCount($dashboard, 'returned_cheques'))->toBe($returnedCheques['rows']->count())
        ->and(financeDashboardCount($dashboard, 'returned_cheques'))->toBe(financeReportCount($returnedChequesReport, 'returned_cheques'));

    Carbon::setTestNow();
});

test('cashbox count persists historical snapshots supports equal variance reopen update print and scope isolation', function (): void {
    $fixture = financeReportFixture($this);
    $actor = financeReportActor();
    foreach (['view', 'create', 'edit', 'reopen', 'print'] as $action) {
        $actor->givePermissionTo(Permission::findOrCreate("finance.cashbox_count.{$action}", 'web'));
    }

    $this->actingAs($actor)->post(route('admin.finance.cashbox-count.store'), [
        'count_date' => '2026-09-30',
        'cashbox_doc_num' => $fixture['cashboxOne']->doc_num,
        'currency_doc_num' => $fixture['currency']->doc_num,
        'actual_amount' => '80.0000',
        'notes' => 'Equal count',
    ])->assertRedirect();

    $equal = CashboxCount::query()->where('notes', 'Equal count')->firstOrFail();
    expect($equal->book_balance)->toBe('80.0000')->and($equal->variance)->toBe('0.0000');
    $this->actingAs($actor)->get(route('admin.finance.cashbox-count.show', $equal))->assertOk()->assertSee('Equal count');
    $this->actingAs($actor)->get(route('admin.finance.cashbox-count.print', $equal))->assertOk()->assertSee($equal->doc_num);
    $this->actingAs($actor)->post(route('admin.finance.cashbox-count.reopen', $equal))->assertRedirect();
    $this->actingAs($actor)->put(route('admin.finance.cashbox-count.update', $equal), [
        'actual_amount' => '75.0000', 'notes' => 'Variance count',
    ])->assertRedirect();
    expect($equal->refresh()->status)->toBe(CashboxCount::StatusSaved)
        ->and($equal->variance)->toBe('-5.0000')
        ->and($equal->book_balance)->toBe('80.0000');

    $otherCompany = Company::query()->create([
        'doc_number' => 9750, 'doc_num' => 'COMP-9750', 'name' => 'Other Count Company', 'status' => 'active', 'is_main' => false,
    ]);
    $otherBranch = Branch::query()->create([
        'doc_number' => 9750, 'doc_num' => 'BR-9750', 'company_id' => $otherCompany->getKey(), 'name' => 'Other Count Branch', 'type' => 'branch', 'status' => 'active',
    ]);
    $otherCurrency = Currency::query()->create([
        'doc_number' => 9750, 'doc_num' => 'CUR-9750', 'company_id' => $otherCompany->getKey(), 'name' => 'Other Count Currency', 'name_en' => 'Other Count Currency', 'code' => 'OCC', 'minor_unit_name' => 'Unit', 'minor_unit_factor' => 100, 'is_main' => true, 'status' => 'active',
    ]);
    $otherAccount = financeReportAccount($otherCompany, 9750, '111975', 'Other Count Cash');
    $otherCashbox = Cashbox::query()->create([
        'doc_number' => 9750, 'doc_num' => 'CASH-9750', 'company_id' => $otherCompany->getKey(), 'branch_id' => $otherBranch->getKey(), 'account_id' => $otherAccount->getKey(), 'name' => 'Other Count Cashbox', 'status' => 'active',
    ]);
    $otherCount = CashboxCount::query()->create([
        'doc_number' => 1, 'doc_num' => 'CCNT-9750', 'company_id' => $otherCompany->getKey(), 'branch_id' => $otherBranch->getKey(), 'cashbox_id' => $otherCashbox->getKey(), 'currency_id' => $otherCurrency->getKey(), 'count_date' => '2026-09-30', 'book_balance' => 0, 'actual_amount' => 0, 'variance' => 0, 'status' => CashboxCount::StatusSaved,
    ]);
    $this->actingAs($actor)->get('/admin/finance/cashbox-count/'.$otherCount->doc_num)->assertNotFound();
});
